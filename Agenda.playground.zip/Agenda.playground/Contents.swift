//AGENDA
struct contacto{
    var nombre:String
    var apellidoP:String
    var apellidoM:String
    var telefono: Int
    var correo:String
    var direccion:String init(nombreA:String,apellidoB:String,apellidoC:String,telefonoD:Int,correoE:String,direccionF:String) {
        self.nombre =  nombreA
        self.apellidoP =  apellidoB
        self.apellidoM = apellidoC
        self.telefono = telefonoD
        self.correo =  correoE
        self.direccion = direccionF
    }
}
var contacto1:contacto = contacto ( nombreA:"Bruno",apellidoB:"Tirado",apellidoC:"Cuevas",telefonoD:"5533456576",correoE:"bruno.tirado@gmail.com",direccionF:"Iztapalapa")
var contacto2: contacto = contacto1
print(contacto1.nombre)
print(contacto1.apellidoP)
print(contacto1.apellidoM)
print(contacto1.telefono)
print(contacto1.correo)
print(contacto1.direccion)

contacto2.nombre = "Antonio"
print(contacto2.nombre)
contacto2.apellidoP = "Cuevas"
print(contacto2.apellidoP)



/*TAREA
 Elaborar una agenda que tenga las siguientes funciones:
 1-Agregar un contacto ingresando todos los datos
 2-Buscar un contacto  por nombre o apellido (Extra)
 3-Eliminar un contacto
 4-Mostrar todos los contactos (Ordenados alfabeticamente)
 
 //Dato:
 nombre
 apellido M
 apellido p
 telefono
 correo
 direccion*/

